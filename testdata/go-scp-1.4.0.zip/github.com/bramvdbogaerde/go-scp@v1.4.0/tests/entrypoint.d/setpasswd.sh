#!/usr/bin/env bash

echo 'bram:$6$9CLVhdvYPsRYjJZJ$UoJbmXrl6F.kL1u1Mnio6gRgKAB7HG0eSeATa.HMu7liRGAINTicM0Ql5/AONVwKXsrA0BbMOOr3BHrODnP2s0' | chpasswd --encrypted
